export class UserDetails {
    file?: string;
    fname?: string;
    lname?: string;
    email?: string;
    phone?: string;
    age?: string;
    city?: string;
    state?: string;
    address?: string;
    address1?: string;
    address2?: string;
    tags?: string;
    che?: string;

    UserDetails() { }

}
